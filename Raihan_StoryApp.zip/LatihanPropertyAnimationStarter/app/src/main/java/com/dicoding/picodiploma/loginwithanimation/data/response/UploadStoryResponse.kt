package com.dicoding.picodiploma.loginwithanimation.data.Response

import com.google.gson.annotations.SerializedName

data class UploadStoryResponse(

    @field:SerializedName("message")
    val message: String? = null,

    @field:SerializedName("error")
    val error: Boolean? = null
)