package com.dicoding.picodiploma.loginwithanimation.di

import android.content.Context
import com.dicoding.picodiploma.loginwithanimation.data.UserRepository
import com.dicoding.picodiploma.loginwithanimation.data.Preference.LocaleDataStore
import com.dicoding.picodiploma.loginwithanimation.data.Preference.UserPreference
import com.dicoding.picodiploma.loginwithanimation.data.Preference.dataStore
import com.dicoding.picodiploma.loginwithanimation.data.Retrofit.ApiConfig

object Injection {
    fun provideRepository(context: Context): UserRepository {
        val pref = UserPreference.getInstance(context.dataStore)
        val apiService = ApiConfig.getApiService()
        val locale = LocaleDataStore.getInstance(context.dataStore)
        return UserRepository.getInstance(apiService, pref, locale)
    }
}